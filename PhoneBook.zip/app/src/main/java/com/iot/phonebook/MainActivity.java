package com.iot.phonebook;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.util.Log;
import org.w3c.dom.NameList;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private static final String DB_NAME = "MyDB";
    private static final int DB_VERSION = 1;
    private PhoneBookDB phoneBookDB;

    private ArrayList<String> data = new ArrayList<>();
    private ArrayList<String> nameList = new ArrayList<>();
    private ArrayList<String> numList = new ArrayList<>();
    private EditText editText;
    public static final String TAG_MSG = "message";
    public static final String TAG_MSG1 = "message";

    static final String KEY_DATA = "KEY_DATA";
    TextView textView;

    int count = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        editText = (EditText) findViewById(R.id.editText);
        ListView list = (ListView) findViewById(R.id.listView);

        textView = (TextView) findViewById(R.id.textView);

        setTitle("전화번호부");

        CustomAdapter adapter = new CustomAdapter(this);
        list.setAdapter(adapter);

        final EditText name = findViewById(R.id.name);
        final EditText num = findViewById(R.id.num);

        Button mypage = (Button) findViewById(R.id.myPage);

        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, data);

        mypage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, MyDetailPage.class);

                startActivity(intent);
            }
        });


        Button button = (Button) findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nameList.add(name.getText().toString());
                numList.add(num.getText().toString());
                adapter.notifyDataSetChanged();
            }
        });



        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override

            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {


                Intent intent = new Intent(MainActivity.this, DetailPage.class);

                String msg = name.getText().toString();
                String msg1 = num.getText().toString();

                intent.putExtra(TAG_MSG, msg);
                intent.putExtra(TAG_MSG1, msg1);

                startActivity(intent);

                adapter1.notifyDataSetChanged();
            }
        });
        if (savedInstanceState != null) {
            nameList = savedInstanceState.getStringArrayList("name");
            numList = savedInstanceState.getStringArrayList("num");
            textView.setText(nameList+"");
            textView.setText(numList+"");
        }

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putStringArrayList("name",nameList);
        outState.putStringArrayList("num",numList);
    }


    private class CustomAdapter extends BaseAdapter {
        Context context;

        public CustomAdapter(Context context) {
            this.context = context;
        }

        @Override
        public int getCount() {
            return nameList.size();
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View itemView = View.inflate(context, R.layout.activity_people_list, null);

            TextView nameItem = itemView.findViewById(R.id.nameItem);
            TextView numItem = itemView.findViewById(R.id.numItem);

            nameItem.setText((nameList.get(position)));
            numItem.setText(numList.get(position));

            return itemView;
        }

    }


}