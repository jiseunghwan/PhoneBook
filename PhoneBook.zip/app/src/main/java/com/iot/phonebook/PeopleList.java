package com.iot.phonebook;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PeopleList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_people_list);
    }
}