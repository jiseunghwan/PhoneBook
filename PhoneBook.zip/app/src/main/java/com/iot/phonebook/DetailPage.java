package com.iot.phonebook;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class DetailPage extends AppCompatActivity {

    private TextView textView;
    private TextView textView1;
    private EditText inputEditText;
    private Button button;
    private TextView textView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_page);



        Intent intent = getIntent();

        String msg = intent.getStringExtra(MainActivity.TAG_MSG);
        TextView textView = (TextView)findViewById(R.id.PeopleName);
        textView.setText(msg);

        String msg1 = intent.getStringExtra(MainActivity.TAG_MSG1);
        TextView textView1 = (TextView)findViewById(R.id.PeopleNum);
        textView1.setText(msg1);



        Button back = (Button) findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(DetailPage.this, MainActivity.class);
                startActivity(intent);
            }
        });

    }

}